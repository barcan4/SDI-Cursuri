package ro.ubb.xml;

/**
 * Created by radu.
 */
public class Book {
}
