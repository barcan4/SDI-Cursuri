package ro.ubb.xml;


import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import java.util.List;

/**
 * Created by radu.
 */
public class Main {
    public static void main(String[] args) {
        List<Book> books=loadData();

        System.out.println("hello");
    }

    private static List<Book> loadData() {

//        DocumentBuilder bd = new DocumentBuilderFactory()
        return null;
    }


}
