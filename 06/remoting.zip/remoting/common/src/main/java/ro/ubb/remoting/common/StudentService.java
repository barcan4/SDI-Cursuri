package ro.ubb.remoting.common;

import java.util.List;

/**
 * Created by radu.
 */
public interface StudentService {
    List<Student> getAllStudents();
}
