package ro.ubb.reflection;

import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.Arrays;

/**
 * Created by radu.
 * <p>
 * * 1.
 * * - create a new "ro.ubb.reflection.Student" instance (reflection).
 * * - initialize the student's private attributes ("name", "groupNumber") with the values ("john", 123).
 * * - print the student instance.
 * * <p>
 * * 2.
 * * - create a new "ro.ubb.reflection.Student" instance (reflection)
 * * - invoke setName("john") and setGroupNumber(123)
 * * - print the student instance.
 * * <p>
 * * 3.
 * * - create a new "ro.ubb.reflection.Student" instance ("john",123) by invoking the constructor
 * * - print the student instance.
 * * <p>
 * * 4.
 * * - create a new "ro.ubb.reflection.Employee". ("ro.ubb.reflection.e04.Employee" extends "ro.ubb.reflection.Person", Person has a
 * * name, Employee has a salary) (reflection)
 * * - set the "name" to "Mary" and the "salary" to 1000;
 * * - print the employee
 * * <p>
 * * 5.
 * * - given a Student instance ("John",123), print all attribute names, types, and values.
 */
public class Main {
    public static void main(String[] args) throws Exception {
        System.out.println("bye");

//        p1();
//        p2();
//        p3();
//        p4();
        p5();
    }

    private static void p5() {
        Student student = new Student("john", 123);

        Field[] fields = student.getClass().getDeclaredFields();
        Arrays.stream(fields).forEach(field -> {
            field.setAccessible(true);
            System.out.println(field.getName());
            System.out.println(field.getType());
            try {
                System.out.println(field.get(student));
            } catch (IllegalAccessException e) {
                e.printStackTrace();
            }
        });

    }

    private static void p4() throws ClassNotFoundException, IllegalAccessException, InstantiationException, NoSuchFieldException {
        Class employeeClass = Class.forName("ro.ubb.reflection.Employee");
        Employee employee = (Employee) employeeClass.newInstance();

        Field salaryField = employeeClass.getDeclaredField("salary");
        salaryField.setAccessible(true);
        salaryField.set(employee, 1000);

        Field nameField = employeeClass.getSuperclass().getDeclaredField("name");
        nameField.setAccessible(true);
        nameField.set(employee, "mary");

        System.out.println(employee);


    }

    private static void p3() throws ClassNotFoundException, NoSuchMethodException, IllegalAccessException, InvocationTargetException, InstantiationException {
        Class studentClass = Class.forName("ro.ubb.reflection.Student");

        Constructor studentConstructor =
                studentClass.getDeclaredConstructor(String.class, int.class);
        Object student = studentConstructor.newInstance("john", 123);

        System.out.println(student);

    }

    private static void p2() throws Exception {
        Class studentClass = Class.forName("ro.ubb.reflection.Student");
        Student student = (Student) studentClass.newInstance();

        Method setNameMethod = studentClass.getMethod("setName", String.class);
        setNameMethod.invoke(student, "john");

        Method setGroupNumberMethod = studentClass.getMethod("setGroupNumber", int.class);
        setGroupNumberMethod.invoke(student, 914);

        System.out.println(student);

    }

    private static void p1() throws ClassNotFoundException, InstantiationException, IllegalAccessException, NoSuchFieldException {
        Class studentClass = Class.forName("ro.ubb.reflection.Student");
        Student student = (Student) studentClass.newInstance();

        Field nameField = studentClass.getDeclaredField("name");
        nameField.setAccessible(true);
        nameField.set(student, "John");
        nameField.setAccessible(false);

        Field groupField = studentClass.getDeclaredField("groupNumber");
        groupField.setAccessible(true);
        groupField.setInt(student, 123);
        groupField.setAccessible(false);

        System.out.println(student);
    }


}
