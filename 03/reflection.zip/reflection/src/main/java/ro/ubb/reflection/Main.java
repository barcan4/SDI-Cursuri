package ro.ubb.reflection;

import java.lang.reflect.Field;

/**
 * Created by radu.
 *
 * * 1.
 *  * - create a new "ro.ubb.reflection.Student" instance (reflection).
 *  * - initialize the student's private attributes ("name", "groupNumber") with the values ("john", 123).
 *  * - print the student instance.
 *  * <p>
 *  * 2.
 *  * - create a new "ro.ubb.reflection.Student" instance (reflection)
 *  * - invoke setName("john") and setGroupNumber(123)
 *  * - print the student instance.
 *  * <p>
 *  * 3.
 *  * - create a new "ro.ubb.reflection.Student" instance ("john",123) by invoking the constructor
 *  * - print the student instance.
 *  * <p>
 *  * 4.
 *  * - create a new "ro.ubb.reflection.Employee". ("ro.ubb.reflection.e04.Employee" extends "ro.ubb.reflection.Person", Person has a
 *  * name, Employee has a salary) (reflection)
 *  * - set the "name" to "Mary" and the "salary" to 1000;
 *  * - print the employee
 *  * <p>
 *  * 5.
 *  * - given a Student instance ("John",123), print all attribute names, types, and values.
 *
 *
 */
public class Main {
    public static void main(String[] args) throws ClassNotFoundException, IllegalAccessException, InstantiationException, NoSuchFieldException {
        System.out.println("bye");

        Class studentClass = Class.forName("ro.ubb.reflection.Student");
        Student student = (Student)studentClass.newInstance();

        Field nameField = studentClass.getDeclaredField("name");
        nameField.setAccessible(true);
        nameField.set(student, "John");
        nameField.setAccessible(false);

        Field groupField = studentClass.getDeclaredField("groupNumber");
        groupField.setAccessible(true);
        groupField.setInt(student, 123);
        groupField.setAccessible(false);

        System.out.println(student);

    }


}
