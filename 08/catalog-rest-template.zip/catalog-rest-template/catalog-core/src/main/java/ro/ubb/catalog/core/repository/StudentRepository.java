package ro.ubb.catalog.core.repository;

import ro.ubb.catalog.core.model.Student;

/**
 * Created by radu.
 */
public interface StudentRepository extends CatalogRepository<Student, Long> {
}
