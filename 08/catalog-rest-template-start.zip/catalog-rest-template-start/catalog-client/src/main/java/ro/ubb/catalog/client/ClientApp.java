package ro.ubb.catalog.client;

/**
 * Created by radu.
 */
public class ClientApp {
    public static void main(String[] args) {


        System.out.println("bye ");
    }
}
