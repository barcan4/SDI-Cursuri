package ro.ubb.springjpa;

/**
 * author: radu
 */
public class Main {
    public static void main(String[] args) {
        System.out.println("hello");
    }
}
