package ro.ubb.springjpa.repository;

import ro.ubb.springjpa.model.Student;

/**
 * Created by radu.
 */
public interface StudentRepository extends CatalogRepository<Student, Long> {
}
