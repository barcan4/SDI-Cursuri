package ro.ubb.springdi.service;

import ro.ubb.springdi.model.Student;

import java.util.List;

/**
 * Created by radu.
 */
public interface StudentService {
    List<Student> getAllStudents();
}
